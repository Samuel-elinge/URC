<?php
/**
 * Logs the admin out by destroying the session, then sends them back
 * to the login page.
 */
session_set_cookie_params([
    'lifetime' => 0,
    'path'     => '/',
    'secure'   => !empty($_SERVER['HTTPS']),
    'httponly' => true,
    'samesite' => 'Lax',
]);
session_start();
$_SESSION = [];
session_destroy();
header('Location: login.php');
exit;
