<?php
/**
 * Shared security helpers for the admin panel.
 * Included by login.php and index.php.
 */

// ---------- CSRF protection ----------
// Generates a one-time token per session, embedded as a hidden field in
// every form. On submit, we check the submitted token matches — this
// stops another website from tricking a logged-in admin's browser into
// submitting actions here without them meaning to (Cross-Site Request
// Forgery). Every POST handler in this app must call csrf_check().

function csrf_token() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrf_field() {
    return '<input type="hidden" name="csrf_token" value="' . htmlspecialchars(csrf_token()) . '">';
}

function csrf_check() {
    $submitted = $_POST['csrf_token'] ?? '';
    $expected  = $_SESSION['csrf_token'] ?? '';
    if ($expected === '' || !hash_equals($expected, $submitted)) {
        http_response_code(403);
        die('Security check failed (invalid or expired form token). Please go back, refresh the page, and try again.');
    }
}

// ---------- Login rate-limiting ----------
// Slows down password-guessing: after 5 failed attempts, the visitor
// (tracked by session, since this app has no user accounts/IP database)
// must wait before trying again, with the wait growing each time.

function login_attempts_allowed() {
    $attempts = $_SESSION['login_attempts'] ?? 0;
    $lockedUntil = $_SESSION['login_locked_until'] ?? 0;
    if ($attempts >= 5 && time() < $lockedUntil) {
        return $lockedUntil - time(); // seconds remaining
    }
    return 0; // 0 = not locked, go ahead
}

function login_attempt_failed() {
    $_SESSION['login_attempts'] = ($_SESSION['login_attempts'] ?? 0) + 1;
    if ($_SESSION['login_attempts'] >= 5) {
        // Lockout grows each time: 30s, then 60s, 120s, etc.
        $extra = $_SESSION['login_attempts'] - 5;
        $wait = 30 * (2 ** $extra);
        $_SESSION['login_locked_until'] = time() + min($wait, 900); // cap at 15 min
    }
}

function login_attempts_reset() {
    unset($_SESSION['login_attempts'], $_SESSION['login_locked_until']);
}

// ---------- Session hardening ----------
// Called once, right after session_start(), on every admin page.

function harden_session() {
    // Regenerate the session ID periodically to limit the damage if a
    // session ID ever leaked (e.g. via a shared/public computer).
    if (empty($_SESSION['created'])) {
        $_SESSION['created'] = time();
    } elseif (time() - $_SESSION['created'] > 1800) {
        session_regenerate_id(true);
        $_SESSION['created'] = time();
    }

    // Auto-logout after 30 minutes of inactivity.
    $timeout = 1800;
    if (!empty($_SESSION['last_activity']) && (time() - $_SESSION['last_activity']) > $timeout) {
        $_SESSION = [];
        session_destroy();
        header('Location: login.php?timeout=1');
        exit;
    }
    $_SESSION['last_activity'] = time();
}
