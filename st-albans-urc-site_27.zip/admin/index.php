<?php
/**
 * This Week — admin panel.
 *
 * Lists, adds, edits, and deletes entries in ../data/posts.json.
 * No database, no WordPress — just this file, a JSON file, and an
 * images folder.
 *
 * Security: session-protected login (see login.php), CSRF-protected
 * forms, hardened session cookies + auto-logout after 30 min idle,
 * strict image-upload validation. See security.php and README.md.
 */

session_set_cookie_params([
    'lifetime' => 0,
    'path'     => '/',
    'secure'   => !empty($_SERVER['HTTPS']),
    'httponly' => true,
    'samesite' => 'Lax',
]);
session_start();

require __DIR__ . '/config.php';
require __DIR__ . '/security.php';

if (empty($_SESSION['admin_authenticated'])) {
    header('Location: login.php');
    exit;
}
harden_session();

$dataFile   = __DIR__ . '/../data/posts.json';
$uploadDir  = __DIR__ . '/../images/news/';
$maxUploadBytes = 5 * 1024 * 1024; // 5MB
$allowedTypes = [
    'image/jpeg' => 'jpg',
    'image/png'  => 'png',
    'image/gif'  => 'gif',
    'image/webp' => 'webp',
];

function load_posts($file) {
    if (!file_exists($file)) return [];
    $json = file_get_contents($file);
    $posts = json_decode($json, true);
    return is_array($posts) ? $posts : [];
}

function save_posts($file, $posts) {
    file_put_contents($file, json_encode($posts, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
}

function next_id($posts) {
    $max = 0;
    foreach ($posts as $p) {
        if ($p['id'] > $max) $max = $p['id'];
    }
    return $max + 1;
}

/**
 * Validates and saves an uploaded image. Returns the new filename on
 * success, null if no file was uploaded, or throws an Exception with a
 * human-readable message on failure.
 *
 * Security notes:
 * - We check the file's actual content via getimagesize(), not just its
 *   extension or the browser-supplied MIME type — both of those can be
 *   spoofed by renaming an arbitrary file. getimagesize() only succeeds
 *   on genuine image data.
 * - We generate a brand-new random filename rather than trusting
 *   anything from the original filename, which closes off path
 *   traversal and "double extension" tricks entirely (e.g. a file
 *   named "shell.php.jpg").
 * - The saved file can only ever end in .jpg/.png/.gif/.webp — never
 *   .php or any other executable extension — so even in the worst case
 *   an uploaded file can't be run as server-side code.
 */
function handle_image_upload($field, $uploadDir, $maxBytes, $allowedTypes) {
    if (empty($_FILES[$field]) || $_FILES[$field]['error'] === UPLOAD_ERR_NO_FILE) {
        return null; // nothing uploaded, not an error
    }
    $file = $_FILES[$field];

    if ($file['error'] !== UPLOAD_ERR_OK) {
        throw new Exception('Image upload failed (error code ' . $file['error'] . ').');
    }
    if ($file['size'] > $maxBytes) {
        throw new Exception('Image is too large — please use a file under 5MB.');
    }

    $imageInfo = @getimagesize($file['tmp_name']);
    if ($imageInfo === false || !isset($allowedTypes[$imageInfo['mime']])) {
        throw new Exception('That file doesn\'t look like a valid JPG, PNG, GIF, or WEBP image.');
    }

    $ext = $allowedTypes[$imageInfo['mime']];
    $filename = bin2hex(random_bytes(8)) . '.' . $ext;

    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }
    if (!move_uploaded_file($file['tmp_name'], $uploadDir . $filename)) {
        throw new Exception('Could not save the uploaded image — check that images/news/ is writable.');
    }

    return $filename;
}

$posts = load_posts($dataFile);
$message = '';
$uploadError = '';
$editing = null;

// ---------- Handle form submissions ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $action = $_POST['action'] ?? '';

    if ($action === 'save') {
        $id         = isset($_POST['id']) && $_POST['id'] !== '' ? (int)$_POST['id'] : null;
        $title      = trim($_POST['title'] ?? '');
        $excerpt    = trim($_POST['excerpt'] ?? '');
        $content    = trim($_POST['content'] ?? '');
        $status     = ($_POST['status'] ?? 'published') === 'draft' ? 'draft' : 'published';
        $publishAt  = trim($_POST['publish_at'] ?? '');
        $removeImg  = isset($_POST['remove_image']);

        if ($title === '' || $content === '' || strip_tags($content) === '') {
            $message = 'Please fill in at least a Title and Content.';
        } else {
            $existingImage = null;
            if ($id !== null) {
                foreach ($posts as $p) {
                    if ($p['id'] === $id) { $existingImage = $p['image'] ?? ''; break; }
                }
            }

            try {
                $uploadedFilename = handle_image_upload('image_upload', $uploadDir, $maxUploadBytes, $allowedTypes);
            } catch (Exception $e) {
                $uploadError = $e->getMessage();
            }

            if ($uploadError === '') {
                $image = $uploadedFilename ?? ($removeImg ? '' : ($existingImage ?? ''));

                $entry = [
                    'title'      => $title,
                    'excerpt'    => $excerpt !== '' ? $excerpt : strip_tags(substr($content, 0, 140)),
                    'content'    => $content,
                    'image'      => $image,
                    'status'     => $status,
                    'publish_at' => $publishAt,
                ];

                if ($id !== null) {
                    foreach ($posts as $i => $p) {
                        if ($p['id'] === $id) {
                            $entry['id'] = $id;
                            $posts[$i] = $entry;
                            break;
                        }
                    }
                    $message = 'Post updated.';
                } else {
                    $entry['id'] = next_id($posts);
                    array_unshift($posts, $entry);
                    $message = 'Post added.';
                }
                save_posts($dataFile, $posts);
                $posts = load_posts($dataFile);
            }
        }
    }

    if ($action === 'delete') {
        $id = (int)($_POST['id'] ?? 0);
        $posts = array_values(array_filter($posts, function ($p) use ($id) {
            return $p['id'] !== $id;
        }));
        save_posts($dataFile, $posts);
        $message = 'Post deleted.';
    }
}

// ---------- Load a post into the edit form if requested ----------
if (isset($_GET['edit'])) {
    $editId = (int)$_GET['edit'];
    foreach ($posts as $p) {
        if ($p['id'] === $editId) {
            $editing = $p;
            break;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>This Week — Admin</title>
<style>
  :root{ --ink-deep:#122820; --gold:#C69B4E; --cream:#FBF8F2; --charcoal:#20241F; }
  body{font-family:Arial,Helvetica,sans-serif;background:var(--cream);margin:0;color:var(--charcoal);}
  header{background:var(--ink-deep);color:#F8F5EE;padding:20px 24px;display:flex;align-items:center;justify-content:space-between;}
  header h1{margin:0;font-size:20px;}
  header a{color:#F8F5EE;font-size:13px;text-decoration:underline;}
  main{max-width:820px;margin:0 auto;padding:28px 20px 60px;}
  .message{background:#fff;border-left:4px solid var(--gold);padding:12px 16px;margin-bottom:24px;border-radius:4px;}
  .message.error{border-left-color:#a33;color:#a33;}
  .card{background:#fff;border-radius:10px;padding:22px 24px;margin-bottom:24px;box-shadow:0 4px 14px rgba(0,0,0,0.06);}
  .card h2{margin-top:0;font-size:18px;}
  label{display:block;font-weight:bold;font-size:13px;margin:14px 0 4px;}
  input[type=text], input[type=file], input[type=datetime-local], select, textarea{
    width:100%;padding:9px 10px;border:1px solid #ccc;border-radius:5px;font-family:inherit;font-size:14px;box-sizing:border-box;
  }
  .hint{font-size:12px;color:#777;margin-top:3px;}
  .btn{background:var(--ink-deep);color:#fff;border:none;padding:10px 20px;border-radius:5px;cursor:pointer;font-size:14px;margin-top:16px;}
  .btn.secondary{background:#888;margin-left:8px;}
  .btn.danger{background:#a33;}
  .post-row{display:flex;justify-content:space-between;align-items:center;padding:14px 0;border-bottom:1px solid #eee;gap:12px;}
  .post-row:last-child{border-bottom:none;}
  .post-row .title{font-weight:bold;}
  .post-row .excerpt{font-size:13px;color:#666;margin-top:2px;}
  .post-row .actions{white-space:nowrap;}
  .post-row .actions a, .post-row .actions button{font-size:13px;margin-left:10px;}
  a.link-btn{color:var(--ink-deep);text-decoration:underline;}
  form.inline{display:inline;}
  .badge{display:inline-block;font-size:11px;font-weight:bold;padding:2px 8px;border-radius:10px;margin-left:8px;text-transform:uppercase;}
  .badge.draft{background:#eee;color:#666;}
  .badge.scheduled{background:#fdf0d5;color:#8a6414;}
  .badge.published{background:#e6f2e9;color:#2f5c3f;}
  .row-inline{display:flex;gap:16px;}
  .row-inline > div{flex:1;}
  .current-image{display:flex;align-items:center;gap:12px;margin-top:8px;}
  .current-image img{height:60px;border-radius:4px;}

  /* ---- Rich text editor ---- */
  .rte-toolbar{display:flex;gap:4px;flex-wrap:wrap;background:#f2f2f2;border:1px solid #ccc;border-bottom:none;border-radius:5px 5px 0 0;padding:6px;}
  .rte-toolbar button{
    background:#fff;border:1px solid #ccc;border-radius:4px;padding:5px 10px;font-size:13px;cursor:pointer;
  }
  .rte-toolbar button:hover{background:#e8e8e8;}
  .rte-toolbar button.active{background:var(--ink-deep);color:#fff;border-color:var(--ink-deep);}
  #contentEditor{
    min-height:160px;border:1px solid #ccc;border-radius:0 0 5px 5px;padding:10px 12px;font-size:14px;
    background:#fff;line-height:1.5;
  }
  #contentEditor:focus{outline:2px solid var(--gold);outline-offset:-1px;}
  #contentEditor p{margin:0 0 10px;}
  #contentEditor a{color:var(--ink-deep);text-decoration:underline;}
</style>
</head>
<body>

<header>
  <h1>This Week — Admin</h1>
  <a href="logout.php">Log out</a>
</header>

<main>
  <?php if ($uploadError): ?>
    <div class="message error"><?php echo htmlspecialchars($uploadError); ?></div>
  <?php elseif ($message): ?>
    <div class="message"><?php echo htmlspecialchars($message); ?></div>
  <?php endif; ?>

  <div class="card">
    <h2><?php echo $editing ? 'Edit Post' : 'Add New Post'; ?></h2>
    <form method="post" enctype="multipart/form-data" id="postForm">
      <?php echo csrf_field(); ?>
      <input type="hidden" name="action" value="save">
      <?php if ($editing): ?>
        <input type="hidden" name="id" value="<?php echo (int)$editing['id']; ?>">
      <?php endif; ?>

      <label for="title">Title</label>
      <input type="text" id="title" name="title" required
             value="<?php echo htmlspecialchars($editing['title'] ?? ''); ?>">

      <label for="excerpt">Short summary (optional — shown on the list page)</label>
      <input type="text" id="excerpt" name="excerpt"
             value="<?php echo htmlspecialchars($editing['excerpt'] ?? ''); ?>">
      <p class="hint">If left blank, this is generated automatically from the start of the content.</p>

      <label for="contentEditor">Content</label>
      <div class="rte-toolbar">
        <button type="button" data-cmd="bold"><b>B</b></button>
        <button type="button" data-cmd="italic"><i>I</i></button>
        <button type="button" data-cmd="underline"><u>U</u></button>
        <button type="button" data-cmd="insertUnorderedList">&bull; List</button>
        <button type="button" data-cmd="insertOrderedList">1. List</button>
        <button type="button" data-cmd="createLink">Link</button>
        <button type="button" data-cmd="unlink">Remove Link</button>
        <button type="button" data-cmd="removeFormat">Clear Formatting</button>
      </div>
      <div id="contentEditor" contenteditable="true"><?php echo $editing['content'] ?? '<p></p>'; ?></div>
      <textarea name="content" id="contentHidden" style="display:none;"></textarea>
      <p class="hint">Select text and use the toolbar to bold, italicise, or link it.</p>

      <label for="image_upload">Image (optional)</label>
      <?php if (!empty($editing['image'])): ?>
        <div class="current-image">
          <img src="../images/news/<?php echo htmlspecialchars($editing['image']); ?>" alt="">
          <label style="display:inline;font-weight:normal;">
            <input type="checkbox" name="remove_image" value="1" style="width:auto;"> Remove this image
          </label>
        </div>
      <?php endif; ?>
      <input type="file" id="image_upload" name="image_upload" accept="image/jpeg,image/png,image/gif,image/webp">
      <p class="hint">JPG, PNG, GIF, or WEBP, up to 5MB. Uploading a new file here replaces any existing image.</p>

      <div class="row-inline">
        <div>
          <label for="status">Status</label>
          <select id="status" name="status">
            <option value="published" <?php echo (($editing['status'] ?? 'published') === 'published') ? 'selected' : ''; ?>>Published</option>
            <option value="draft" <?php echo (($editing['status'] ?? '') === 'draft') ? 'selected' : ''; ?>>Draft (not visible on the site yet)</option>
          </select>
        </div>
        <div>
          <label for="publish_at">Publish date/time (optional)</label>
          <input type="datetime-local" id="publish_at" name="publish_at"
                 value="<?php echo htmlspecialchars($editing['publish_at'] ?? ''); ?>">
        </div>
      </div>
      <p class="hint">Leave "Publish date/time" blank to publish immediately (if Status is "Published"). Set a future date/time to schedule it — it'll automatically appear on the site at that moment, no further action needed.</p>

      <button type="submit" class="btn"><?php echo $editing ? 'Save Changes' : 'Add Post'; ?></button>
      <?php if ($editing): ?>
        <a href="index.php" class="btn secondary" style="display:inline-block;text-decoration:none;">Cancel</a>
      <?php endif; ?>
    </form>
  </div>

  <div class="card">
    <h2>Existing Posts (<?php echo count($posts); ?>)</h2>
    <?php if (empty($posts)): ?>
      <p>No posts yet — add one above.</p>
    <?php else: ?>
      <?php foreach ($posts as $p): ?>
        <?php
          $status = $p['status'] ?? 'published';
          $publishAt = $p['publish_at'] ?? '';
          if ($status === 'draft') {
              $badge = '<span class="badge draft">Draft</span>';
          } elseif ($publishAt !== '' && strtotime($publishAt) > time()) {
              $badge = '<span class="badge scheduled">Scheduled</span>';
          } else {
              $badge = '<span class="badge published">Live</span>';
          }
        ?>
        <div class="post-row">
          <div>
            <div class="title"><?php echo htmlspecialchars($p['title']); ?><?php echo $badge; ?></div>
            <div class="excerpt"><?php echo htmlspecialchars($p['excerpt']); ?></div>
          </div>
          <div class="actions">
            <a class="link-btn" href="index.php?edit=<?php echo (int)$p['id']; ?>">Edit</a>
            <form class="inline" method="post" onsubmit="return confirm('Delete this post? This cannot be undone.');">
              <?php echo csrf_field(); ?>
              <input type="hidden" name="action" value="delete">
              <input type="hidden" name="id" value="<?php echo (int)$p['id']; ?>">
              <button type="submit" class="btn danger">Delete</button>
            </form>
          </div>
        </div>
      <?php endforeach; ?>
    <?php endif; ?>
  </div>

  <p><a class="link-btn" href="../blog.html" target="_blank">View the live "This Week" page &rarr;</a></p>
</main>

<script>
  // ---------- Minimal rich text editor ----------
  // Uses the browser's built-in execCommand for basic formatting —
  // no external library needed. Works fine for bold/italic/links/lists,
  // which covers what a church newsletter actually needs.
  var editor = document.getElementById('contentEditor');
  var hidden = document.getElementById('contentHidden');

  document.querySelectorAll('.rte-toolbar button').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var cmd = btn.getAttribute('data-cmd');
      editor.focus();
      if (cmd === 'createLink') {
        var url = prompt('Enter the web address to link to:', 'https://');
        if (url) document.execCommand(cmd, false, url);
      } else {
        document.execCommand(cmd, false, null);
      }
    });
  });

  // Sync the editor's HTML into the hidden textarea right before the
  // form submits, since that's the field the server actually reads.
  document.getElementById('postForm').addEventListener('submit', function () {
    hidden.value = editor.innerHTML;
  });
</script>

</body>
</html>
