<?php
/**
 * Admin password config.
 *
 * CHANGE THIS before (or right after) the site goes live — this file
 * ships with a randomly generated placeholder password so it's not
 * guessable, but you should still set your own.
 *
 * How to change it: just edit the string below and save. No hashing,
 * no tools needed — this file never gets displayed to visitors (PHP
 * files execute on the server, they don't show their source code when
 * requested), so a plain password here is fine as long as this file
 * stays where it is.
 */

define('ADMIN_PASSWORD', '7d1aH03Tg4oBBj');
