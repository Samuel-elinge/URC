<?php
/**
 * Password gate for /admin/.
 *
 * Sets a PHP session on success, so index.php can check "is this visitor
 * logged in?" before showing anything. See config.php to change the
 * password.
 *
 * Security features:
 * - Rate-limited: 5 failed attempts triggers a growing lockout
 * - CSRF-protected: the login form itself carries a one-time token
 * - Constant-time password comparison (hash_equals) so response timing
 *   can't be used to guess the password character by character
 * - Session cookie hardened (HttpOnly, Secure when on HTTPS, SameSite)
 */

// Harden the session cookie BEFORE starting the session, so these
// settings actually apply to the cookie the browser receives.
session_set_cookie_params([
    'lifetime' => 0,
    'path'     => '/',
    'secure'   => !empty($_SERVER['HTTPS']),
    'httponly' => true,
    'samesite' => 'Lax',
]);
session_start();

require __DIR__ . '/config.php';
require __DIR__ . '/security.php';

$error = '';
$waitSeconds = login_attempts_allowed();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $waitSeconds === 0) {
    csrf_check();
    $submitted = $_POST['password'] ?? '';
    if (hash_equals(ADMIN_PASSWORD, $submitted)) {
        login_attempts_reset();
        session_regenerate_id(true); // fresh session ID on login, prevents session fixation
        $_SESSION['admin_authenticated'] = true;
        $_SESSION['created'] = time();
        $_SESSION['last_activity'] = time();
        header('Location: index.php');
        exit;
    } else {
        login_attempt_failed();
        $waitSeconds = login_attempts_allowed();
        $error = $waitSeconds > 0
            ? "Too many attempts. Please wait {$waitSeconds} seconds and try again."
            : 'Incorrect password. Please try again.';
    }
} elseif ($waitSeconds > 0) {
    $error = "Too many attempts. Please wait {$waitSeconds} seconds and try again.";
}

$timedOut = isset($_GET['timeout']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>This Week — Admin Login</title>
<style>
  :root{ --ink-deep:#122820; --gold:#C69B4E; --cream:#FBF8F2; --charcoal:#20241F; }
  body{
    font-family:Arial,Helvetica,sans-serif;background:var(--cream);margin:0;color:var(--charcoal);
    display:flex;align-items:center;justify-content:center;min-height:100vh;
  }
  .box{background:#fff;border-radius:10px;padding:32px 30px;width:100%;max-width:320px;box-shadow:0 8px 24px rgba(0,0,0,0.1);}
  .box h1{font-size:18px;margin:0 0 20px;color:var(--ink-deep);text-align:center;}
  label{display:block;font-weight:bold;font-size:13px;margin-bottom:6px;}
  input[type=password]{width:100%;padding:10px 12px;border:1px solid #ccc;border-radius:5px;font-size:14px;box-sizing:border-box;}
  .btn{width:100%;background:var(--ink-deep);color:#fff;border:none;padding:11px;border-radius:5px;cursor:pointer;font-size:14px;margin-top:16px;}
  .btn:disabled{background:#aaa;cursor:not-allowed;}
  .error{background:#fbeaea;color:#a33;padding:10px 12px;border-radius:5px;font-size:13px;margin-bottom:16px;}
  .notice{background:#eef5ee;color:#2f5c3f;padding:10px 12px;border-radius:5px;font-size:13px;margin-bottom:16px;}
</style>
</head>
<body>
  <div class="box">
    <h1>This Week — Admin</h1>
    <?php if ($timedOut && !$error): ?>
      <div class="notice">You were logged out after being idle. Please log in again.</div>
    <?php endif; ?>
    <?php if ($error): ?>
      <div class="error"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>
    <form method="post">
      <?php echo csrf_field(); ?>
      <label for="password">Password</label>
      <input type="password" id="password" name="password" required autofocus <?php echo $waitSeconds > 0 ? 'disabled' : ''; ?>>
      <button type="submit" class="btn" <?php echo $waitSeconds > 0 ? 'disabled' : ''; ?>>Log in</button>
    </form>
  </div>
</body>
</html>
