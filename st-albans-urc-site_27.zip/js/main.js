// ============================================================
// St Albans URC — shared site behaviour
// Used by: index.html, services.html, contact.html
// ============================================================

document.addEventListener('DOMContentLoaded', function () {

  // ---------- Highlight the current page in the nav ----------
  // Since header.html is one shared partial, we mark the active link
  // at runtime by matching the current filename, rather than needing
  // a separate header variant per page.
  var currentPage = window.location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.nav-row a.top').forEach(function (link) {
    var linkPage = link.getAttribute('href');
    if (linkPage === currentPage) {
      link.classList.add('active');
    }
  });

  // ---------- Mobile nav toggle ----------
  var menuToggle = document.getElementById('menuToggle');
  var navRow = document.getElementById('navRow');
  menuToggle?.addEventListener('click', function () {
    navRow?.classList.toggle('open');
  });

  // On mobile, tapping a parent nav link opens its submenu instead of navigating
  document.querySelectorAll('.nav-row > div').forEach(function (item) {
    if (item.querySelector('.dropdown')) {
      var link = item.querySelector('a.top');
      link.addEventListener('click', function (e) {
        if (window.innerWidth <= 880) {
          e.preventDefault();
          item.classList.toggle('submenu-open');
        }
      });
    }
  });

  // ---------- Visitor "Plan your visit" drawer ----------
  var planVisitBtn = document.getElementById('planVisitBtn');
  var drawerCloseBtn = document.getElementById('drawerCloseBtn');
  var drawerOverlay = document.getElementById('drawerOverlay');
  var visitorDrawer = document.getElementById('visitorDrawer');

  function openDrawer() {
    visitorDrawer?.classList.add('open');
    drawerOverlay?.classList.add('open');
  }
  function closeDrawer() {
    visitorDrawer?.classList.remove('open');
    drawerOverlay?.classList.remove('open');
  }
  planVisitBtn?.addEventListener('click', openDrawer);
  drawerCloseBtn?.addEventListener('click', closeDrawer);
  drawerOverlay?.addEventListener('click', closeDrawer);

  // ---------- Info-card click delegation (homepage coloured blocks) ----------
  // Cards are <div>s (not <a>s) because some contain a real nested link
  // (e.g. an inline "Calendar" link) — you can't validly nest <a> inside <a>.
  // Clicking anywhere on the card navigates to its data-href, UNLESS the
  // click was on a real link inside it (Learn More, or an inline Calendar
  // link), which then behaves normally.
  document.querySelectorAll('.info-card[data-href]').forEach(function (card) {
    card.addEventListener('click', function (e) {
      if (e.target.closest('a')) return; // let real links behave normally
      window.location.href = card.getAttribute('data-href');
    });
  });

  // ---------- Contact & Newsletter forms ----------
  // Both use action="mailto:..." to handle the actual sending (opens the
  // visitor's email client with the message pre-filled) — we just show a
  // friendly confirmation alongside it, without blocking that behaviour.
  ['contactForm', 'newsletterForm'].forEach(function (formId) {
    var form = document.getElementById(formId);
    form?.addEventListener('submit', function (e) {
      var noticeId = formId === 'contactForm' ? 'formNotice' : 'newsletterNotice';
      var notice = document.getElementById(noticeId);
      if (notice) notice.style.display = 'block';
      // Intentionally NOT calling e.preventDefault() — the mailto: action
      // needs to fire so the visitor's email client actually opens.
    });
  });

});
