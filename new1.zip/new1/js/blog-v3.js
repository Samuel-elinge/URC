// ============================================================
// St Albans URC — Blog (headless WordPress via REST API)
//
// This site stays static/plain-HTML everywhere else. Only the Blog
// section talks to a WordPress install, purely as a content source —
// via WordPress's built-in REST API (no theme, no plugins required
// on the WP side beyond the one CORS snippet noted in README.md).
// ============================================================

// -----------------------------------------------------------------
// CONFIG — change this one line once your WordPress install is live.
// e.g. 'https://blog.stalbansurc.org/wp-json/wp/v2'
//      or 'https://stalbansurc.org/wp-blog/wp-json/wp/v2' if WP
//      lives in a subfolder instead of a subdomain.
// -----------------------------------------------------------------
const WP_API_BASE = 'https://stalbansurc.org/dev/wp-json/wp/v2';
const POSTS_PER_PAGE = 6;

// ---------- Helpers ----------

function formatDate(isoString) {
  const d = new Date(isoString);
  return d.toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' });
}

// WordPress returns title/excerpt/content as { rendered: "<p>...</p>" } objects,
// and strips/encodes HTML entities in excerpts — this just unwraps them safely.
function stripTags(html) {
  const tmp = document.createElement('div');
  tmp.innerHTML = html;
  return tmp.textContent || tmp.innerText || '';
}

async function fetchJSON(url) {
  const res = await fetch(url);
  if (!res.ok) {
    throw new Error('WordPress API request failed (' + res.status + ')');
  }
  return { data: await res.json(), headers: res.headers };
}

// ---------- Blog listing page (blog.html) ----------

// Rotating palette matching the rest of the site's brand colors — used as
// a fallback background behind each post's date badge, and to tint posts
// that have no featured image set.
const ROW_COLORS = ['#1E3B32', '#1F4A52', '#6B2F3A', '#8A6A1E', '#2C4F6B', '#8C4A2F', '#4E3B63', '#3F5E3A'];

function formatDayMonth(isoString) {
  const d = new Date(isoString);
  return {
    day: d.getDate(),
    month: d.toLocaleDateString('en-GB', { month: 'short' }),
  };
}

async function renderBlogList(page = 1) {
  const container = document.getElementById('blogPosts');
  const paginationEl = document.getElementById('blogPagination');
  if (!container) return;

  container.innerHTML = '<p class="blog-state">Loading posts&hellip;</p>';

  try {
    const url = `${WP_API_BASE}/posts?per_page=${POSTS_PER_PAGE}&page=${page}&_embed`;
    const { data: posts, headers } = await fetchJSON(url);
    const totalPages = parseInt(headers.get('X-WP-TotalPages') || '1', 10);

    if (!posts.length) {
      container.innerHTML = '<p class="blog-state">No posts published yet — check back soon.</p>';
      if (paginationEl) paginationEl.innerHTML = '';
      return;
    }

    container.innerHTML = '';
    container.className = 'blog-list';

    posts.forEach((post, i) => {
      const featuredMedia =
        post._embedded &&
        post._embedded['wp:featuredmedia'] &&
        post._embedded['wp:featuredmedia'][0];
      const imageUrl = featuredMedia ? featuredMedia.source_url : null;
      const color = ROW_COLORS[i % ROW_COLORS.length];
      const { day, month } = formatDayMonth(post.date);

      const row = document.createElement('a');
      row.className = 'blog-row';
      row.href = `blog-post.html?slug=${encodeURIComponent(post.slug)}`;

      const visualStyle = imageUrl
        ? `background-image:url('${imageUrl}');`
        : `background-color:${color};`;

      row.innerHTML = `
        <div class="blog-row-visual" style="${visualStyle}">
          <div class="blog-row-date">
            <span class="day">${day}</span>
            <span class="month">${month}</span>
          </div>
        </div>
        <div class="blog-row-body">
          <div class="blog-row-text">
            <h3>${post.title.rendered}</h3>
            <p class="blog-row-fulldate">${formatDate(post.date)}</p>
            <div class="blog-row-excerpt"><p>${stripTags(post.excerpt.rendered).trim()}</p></div>
          </div>
          <span class="blog-row-cta">More Details</span>
        </div>
      `;
      container.appendChild(row);
    });

    // ---------- Pagination ----------
    if (paginationEl) {
      if (totalPages <= 1) {
        paginationEl.innerHTML = '';
      } else {
        paginationEl.innerHTML = `
          <button id="blogPrev" ${page <= 1 ? 'disabled' : ''}>&larr; Newer</button>
          <span class="page-indicator">Page ${page} of ${totalPages}</span>
          <button id="blogNext" ${page >= totalPages ? 'disabled' : ''}>Older &rarr;</button>
        `;
        document.getElementById('blogPrev')?.addEventListener('click', () => {
          if (page > 1) renderBlogList(page - 1);
        });
        document.getElementById('blogNext')?.addEventListener('click', () => {
          if (page < totalPages) renderBlogList(page + 1);
        });
      }
    }
  } catch (err) {
    console.error(err);
    container.innerHTML = `
      <p class="blog-state error">
        Couldn't load posts right now. If you're setting this up for the first time,
        check that <code>WP_API_BASE</code> in <code>js/blog-v3.js</code> points at your
        WordPress site, and that its REST API is reachable (see README.md).
      </p>`;
    if (paginationEl) paginationEl.innerHTML = '';
  }
}

// ---------- Single blog post page (blog-post.html) ----------

async function renderBlogPost() {
  const container = document.getElementById('blogPost');
  if (!container) return;

  const params = new URLSearchParams(window.location.search);
  const slug = params.get('slug');

  if (!slug) {
    container.innerHTML = '<p class="blog-state error">No post specified.</p>';
    return;
  }

  container.innerHTML = '<p class="blog-state">Loading post&hellip;</p>';

  try {
    const url = `${WP_API_BASE}/posts?slug=${encodeURIComponent(slug)}&_embed`;
    const { data: posts } = await fetchJSON(url);

    if (!posts.length) {
      container.innerHTML = '<p class="blog-state error">Post not found.</p>';
      return;
    }

    const post = posts[0];
    const featuredMedia =
      post._embedded &&
      post._embedded['wp:featuredmedia'] &&
      post._embedded['wp:featuredmedia'][0];
    const imageUrl = featuredMedia ? featuredMedia.source_url : null;

    document.title = stripTags(post.title.rendered) + ' — St Albans URC Blog';

    container.innerHTML = `
      <a class="blog-back" href="blog.html">&larr; Back to Blog</a>
      <p class="blog-post-date">${formatDate(post.date)}</p>
      <h1>${post.title.rendered}</h1>
      ${imageUrl ? `<img class="blog-post-image" src="${imageUrl}" alt="">` : ''}
      <div class="blog-post-content">${post.content.rendered}</div>
      <p style="margin-top:40px;"><a class="blog-back" href="blog.html">&larr; Back to Blog</a></p>
    `;
  } catch (err) {
    console.error(err);
    container.innerHTML = `
      <p class="blog-state error">
        Couldn't load this post right now. If you're setting this up for the first time,
        check that <code>WP_API_BASE</code> in <code>js/blog-v3.js</code> points at your
        WordPress site, and that its REST API is reachable (see README.md).
      </p>`;
  }
}

// ---------- Auto-run on the right page ----------

document.addEventListener('DOMContentLoaded', function () {
  if (document.getElementById('blogPosts')) {
    renderBlogList(1);
  }
  if (document.getElementById('blogPost')) {
    renderBlogPost();
  }
});
